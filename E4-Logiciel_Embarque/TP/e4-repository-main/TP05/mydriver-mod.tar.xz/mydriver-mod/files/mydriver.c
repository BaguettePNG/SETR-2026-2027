#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/device.h>
#include <linux/cdev.h>

#define DEVICE_NAME "mychardev"
#define BUFFER_SIZE 1024

static char device_buffer[BUFFER_SIZE];
static int buffer_len = 0;
static dev_t dev_num; // Major/Minor number
static struct class *my_class;
static struct cdev my_cdev;

// Fonction d'ouverture
static int my_open(struct inode *inode, struct file *file) {
    pr_info("mychardev: Device opened\n");
    return 0;
}

// Fonction de fermeture
static int my_close(struct inode *inode, struct file *file) {
    pr_info("mychardev: Device closed\n");
    return 0;
}

// Fonction de lecture
static ssize_t my_read(struct file *file, char __user *user_buffer, size_t count, loff_t *offset) {
    size_t bytes_to_read = min((size_t)(buffer_len - *offset), count);

    pr_info("mychardev: Read %zu bytes\n", bytes_to_read);
    return bytes_to_read;
}

// Fonction d'écriture
static ssize_t my_write(struct file *file, const char __user *user_buffer, size_t count, loff_t *offset) {
    size_t bytes_to_write = min((size_t)(BUFFER_SIZE - *offset), count);


    pr_info("mychardev: Written %zu bytes\n", bytes_to_write);
    return bytes_to_write;
}

// Structure des opérations sur le fichier
static const struct file_operations my_fops = {
    .owner = THIS_MODULE,
    .open = my_open,
    .release = my_close,
    .read = my_read,
    .write = my_write,
};

// Fonction d'initialisation du module
static int __init my_init(void) {


    pr_info("mychardev: Device initialized successfully\n");
    return 0;
}

// Fonction de nettoyage du module
static void __exit my_exit(void) {

    pr_info("mychardev: Device unregistered\n");
}

module_init(my_init);
module_exit(my_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("SETR");
MODULE_DESCRIPTION("Module Linux Kernel");
MODULE_VERSION("1.0");
